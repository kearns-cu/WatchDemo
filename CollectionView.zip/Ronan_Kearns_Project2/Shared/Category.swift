//
//  Category.swift
//  ListNavDemo
//
//  Created by Ronan Kearns on 10/18/23.
//

import Foundation

struct Category: Identifiable {
    var id: UUID = UUID()
    var name: String
    var cars: [Car]
}
