//
//  WatchStore.swift
//  ListNavDemo
//
//  Created by Ronan Kearns on 10/18/23.
//

import SwiftUI
import Combine

class WatchStore : ObservableObject {
    @Published var watches: [Watch]
    //stores watches inside array
    init(watches: [Watch] = []) {
        self.watches = watches
    }
}
