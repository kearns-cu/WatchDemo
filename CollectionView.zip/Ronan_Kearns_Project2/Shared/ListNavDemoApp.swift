//
//  ListNavDemoApp.swift
//  Shared
//
//  Created by Ronan Kearns on 10/17/23.
//

import SwiftUI

@main
struct ListNavDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
