//
//  MessageView.swift
//  WatchShopDemo
//
//  Created by Samith Lakka  on 12/10/23.
//

import Foundation
import SwiftUI

struct Message: Identifiable {
    let id: Int
    let text: String
    let sender: String
    let timestamp: String
    let isFromUser: Bool
}

struct Conversation: Identifiable {
    let id: Int
    let messages: [Message]
}

struct ChatMessageView: View {
    
    let conversations: [Conversation] = [
        Conversation(id: 1, messages: [
            Message(id: 1, text: "Hello there! Thank you for Purchasing my product. It will arrive in 3-4 business days.", sender: "Samith", timestamp: "10:45 AM", isFromUser: false),
            Message(id: 2, text: "Ok thank you!", sender: "You", timestamp: "10:46 AM", isFromUser: true),
            Message(id: 3, text: "No problem! If you have any further questions let me know!", sender: "Samith", timestamp: "10:47 AM", isFromUser: false)
        ]),
        Conversation(id: 2, messages: [
            Message(id: 1, text: "Hello there!", sender: "Ronan", timestamp: "10:45 AM", isFromUser: false),
            Message(id: 2, text: "Hi, Ronan! How are you?", sender: "You", timestamp: "10:46 AM", isFromUser: true),
            Message(id: 3, text: "I'm good, thanks for asking!", sender: "Ronan", timestamp: "10:47 AM", isFromUser: false)
        ]),
        Conversation(id: 3, messages: [
            Message(id: 1, text: "Hello there!", sender: "Joe", timestamp: "10:45 AM", isFromUser: false),
            Message(id: 2, text: "Hi, Ronan! How are you?", sender: "You", timestamp: "10:46 AM", isFromUser: true),
            Message(id: 3, text: "I'm good, thanks for asking!", sender: "Joe", timestamp: "10:47 AM", isFromUser: false)
        ]),
    ]
    var body: some View {
        NavigationView {
            List(conversations) { conversation in
                if let firstMessage = conversation.messages.first {
                    NavigationLink(destination: ConversationDetailView(conversation: conversation)) {
                        MessagePreview(message: firstMessage)
                    }
                }
            }
            .navigationTitle("Conversations")
        }
    }
}

struct ConversationDetailView: View {
    let conversation: Conversation

    var body: some View {
        List(conversation.messages) { message in
            SingleMessageView(message: message)
        }
        .navigationTitle("Conversation")
    }
}

struct MessagePreview: View {
    let message: Message

    var body: some View {
        VStack(alignment: .leading) {
            Text(message.sender).font(.headline)
            Text(message.text).font(.body)
            Text(message.timestamp).font(.footnote).foregroundColor(.gray)
        }
    }
}

struct SingleMessageView: View {
    let message: Message

    var body: some View {
        HStack {
            if message.isFromUser {
                Spacer()
            }
            VStack(alignment: .leading) {
                Text(message.sender).font(.headline)
                Text(message.text).font(.body)
                Text(message.timestamp).font(.footnote).foregroundColor(.gray)
            }
            if !message.isFromUser {
                Spacer()
            }
        }
    }
}







