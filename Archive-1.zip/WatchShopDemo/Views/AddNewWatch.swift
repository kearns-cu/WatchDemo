//
//  AddNewWatch.swift
//  ListNavDemo
//
//  Created by Ronan Kearns on 10/18/23.
//

import SwiftUI
import PhotosUI

@available(iOS 16.0, *)
final class PhotoPickerViewModel: ObservableObject {
    
    @Published private(set) var selectedImage: UIImage? = nil
    @Published var imageSelection: PhotosPickerItem? = nil {
        didSet{
            setImage(from: imageSelection)
        }
    }
    
    private func setImage(from selection: PhotosPickerItem?) {
        guard let selection else {return}
        
        Task{
            if let data = try? await selection.loadTransferable(type: Data.self){
                if let uiImage = UIImage(data: data){
                    selectedImage = uiImage
                    return
                }
            }
        }
    }
}

@available(iOS 16.0, *)
struct AddNewWatch: View {
    @StateObject private var viewModel = PhotoPickerViewModel()
    
    //creates store to store new watch
    @StateObject var watchStore: WatchStore
    //presets gold to false
    @State private var isGold = false
    //sets name to null
    @State private var name: String = ""
    //sets description to null
    @State private var description: String = ""
    //@State private var type: String = ""
    //@State private var releaseYear: String = ""
    //@State private var yearStopped: String = ""
    //@State private var brand: String = ""
    //@State private var family: String = ""
    //@State private var caseBack: String = ""
    //@State private var caseDiameter: String = ""

    var body: some View {
        //form for inputting watch details
        Form {
            Section(header: Text("Watch Details")) {
                if let image = viewModel.selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 200)
                        .cornerRadius(10)
                }
                
                PhotosPicker(selection: $viewModel.imageSelection, matching: .images) {
                    Text("Select Photo")
                        .foregroundColor(.red)
                }
                
                //box to enter model name
                DataInput(title: "Model", userInput: $name)
                //box to enter model description
                DataInput(title: "Description", userInput: $description)
                //toggle to set watch to gold
                Toggle(isOn: $isGold) {
                        Text("Gold").font(.headline)
                }.padding()
            }
            //button to add watch
            Button(action: addNewWatch) {
                Text("Add Watch")
                }
            }
    }

    func addNewWatch() {
        //add watch to array of stored watches
        let newWatch = Watch(id: UUID().uuidString,
                      name: name, description: description,
                             isGold: isGold, imageName: "rolex_submariner", seller: "Joe" )
        
        watchStore.watches.append(newWatch)
    }

}

struct DataInput: View {
    
    var title: String
    @Binding var userInput: String
    //view for form
    var body: some View {
        VStack(alignment: HorizontalAlignment.leading) {
            Text(title)
                .font(.headline)
            TextField("Enter \(title)", text: $userInput)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
        }
        .padding()
    }
}

@available(iOS 16.0, *)
struct AddNewWatch_Previews: PreviewProvider {
    static var previews: some View {
        AddNewWatch(watchStore: WatchStore(watches: watchData))
    }
}
