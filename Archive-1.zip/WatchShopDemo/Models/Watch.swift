//
//  Watch.swift
//  ListNavDemo
//
//  Created by Ronan Kearns on 10/18/23.
//

import SwiftUI

struct Watch : Codable, Identifiable {
    //stores watch
    var id: String
    //identifies watch
    var name: String
    //describes watch
    var description: String
    //checks if watch is gold
    var isGold: Bool
    //stores watch image
    var imageName: String
    //watch seller
    var seller: String
}
