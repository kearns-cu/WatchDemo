//
//  OrdersViewModel.swift
//  WatchShopDemo
//
//  Created by Samith Lakka  on 12/11/23.
//

import Foundation
import SwiftUI
class ProductViewModel: ObservableObject {
    @Published var products: [Product] = []

    func loadProducts() {
        products = [
            Product(name: "Rolex Pepsi", image: "Watch1", price: 20000, seller: "Samith"),
            Product(name: "Rolex Coke", image: "Watch2", price: 25000, seller: "Ronan"),
            Product(name: "Rolex Gold", image: "Watch3", price: 40000, seller: "Joe")
        ]
    }
}
