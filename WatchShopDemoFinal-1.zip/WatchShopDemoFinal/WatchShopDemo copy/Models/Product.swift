//
//  Product.swift
//  WatchShopDemo
//
//  Created by Ronan Kearns on 11/30/23.
//

import Foundation

struct Product: Identifiable{
    var id = UUID()
    var name: String
    var image: String
    var price: Int
    var seller: String
}

var productList = [Product(name: "Rolex Pepsi", image: "Watch1", price: 20000, seller: "Samith"),
                   Product(name: "Rolex Coke", image: "Watch2", price: 25000, seller: "Ronan"),
                   Product(name: "Rolex Gold", image: "Watch3", price: 40000, seller: "Joe")
]
