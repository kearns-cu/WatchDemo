//
//  CartView.swift
//  WatchShopDemo
//
//  Created by Ronan Kearns on 11/30/23.
//

import SwiftUI

// Assuming the CartManager and other necessary models are already defined

struct CartView: View {
    @EnvironmentObject var cartManager: CartManager
    
    // This state variable controls the navigation
    @State private var shouldNavigateToOrders = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                if cartManager.products.count > 0 {
                    ForEach(cartManager.products, id: \.id) { product in
                        ProductRow(product: product)
                    }
                    
                    HStack {
                        Text("Your cart total is")
                        Spacer()
                        Text("$\(cartManager.total).00")
                            .bold()
                    }
                    .padding()
                    
                    // Updated PaymentButton with navigation action
                    PaymentButton {
                        // Here you would handle the payment
                        // If the payment is successful, trigger navigation
                        self.shouldNavigateToOrders = true
                    }
                    .padding()
                    
                    // Invisible NavigationLink that is activated programmatically
                    NavigationLink(destination: CurrentOrdersView().navigationBarBackButtonHidden(true), isActive: $shouldNavigateToOrders) {
                        EmptyView()
                    }
                    
                } else {
                    Text("Your cart is empty")
                }
            }
            .navigationTitle(Text("My Cart"))
            .padding(.top)
        }
    }
}

// For preview in Xcode
struct CartView_Previews: PreviewProvider {
    static var previews: some View {
        CartView()
            .environmentObject(CartManager())
    }
}


