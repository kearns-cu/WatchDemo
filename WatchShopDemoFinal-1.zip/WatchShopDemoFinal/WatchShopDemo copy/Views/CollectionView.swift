//
//  CollectionView.swift
//  WatchShopDemo
//
//  Created by Ronan Kearns on 12/10/23.
//


import SwiftUI

struct CollectionView: View {
    //initializes stored array of watches
    @StateObject private var watchStore: WatchStore = WatchStore(watches: watchData)
    
    var body: some View {
        NavigationView {
            //list of displayed watches
            List {
                ForEach(watchStore.watches) { watch in
                    ListCell(watch: watch)
                }
                //deletes watch
                .onDelete(perform: deleteItems)
                //moves watch in list
                .onMove(perform: moveItems)
            }
            .navigationBarTitle(Text("Rolex Collection"))
            .navigationBarItems(leading: NavigationLink(destination:
                                                            AddNewWatch(watchStore: self.watchStore)) {
                //add watch button
                Text("Add")
                    .foregroundColor(.blue)
                //edit button
            }, trailing: EditButton())
        }
    }
    
    //deletes watch from list array
    func deleteItems(at offsets: IndexSet) {
        watchStore.watches.remove(atOffsets: offsets)
    }
    //moves watch in list array
    func moveItems(from source: IndexSet, to destination: Int) {
        watchStore.watches.move(fromOffsets: source, toOffset: destination)
    }
}
    
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        CollectionView()
    }
}

struct ListCell: View {
    var watch: Watch
    //view of watch list and add/edit features
    var body: some View {
        NavigationLink(destination: WatchDetail(selectedWatch: watch)) {
            HStack {
                Image(watch.imageName)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 100, height: 60)
                Text(watch.name)
            }
        }
    }
}

