//
//  CurrentOrderView.swift
//  WatchShopDemo
//
//  Created by Samith Lakka  on 12/10/23.
//
import Foundation
import SwiftUI
struct CurrentOrdersView: View {
    @ObservedObject var viewModel = ProductViewModel()
    @State private var shouldNavigateToMessages = false
    var body: some View {
        NavigationView {
            List(viewModel.products, id: \.id) { product in
                VStack(alignment: .leading) {
                    Text(product.name)
                        .font(.headline)
                    Image(product.image)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                    Text("Price: $\(product.price)")
                        .font(.subheadline)
                    Text(product.seller)
                    Button(action: {
                                    self.shouldNavigateToMessages = true
                                }) {
                                    Text("Messages")
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 50)
                                        .background(Color.blue)
                                        .cornerRadius(10)
                                }
                                .padding()
                    NavigationLink(destination: ChatMessageView(), isActive: $shouldNavigateToMessages) {
                                    EmptyView()
                                }
                }
            }
            .navigationBarTitle("Current Orders")
            .onAppear {
                viewModel.loadProducts()
            }
        }
    }
}

struct CurrentOrdersView_Previews: PreviewProvider {
    static var previews: some View {
        CurrentOrdersView()
    }
}
