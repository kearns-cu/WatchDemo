//
// WatchDetail.swift
// ListNavDemo
//
// Created by Ronan Kearns on 10/18/23.
//

import SwiftUI

// Watch View
struct WatchDetail: View {
    
    // Stores selected watch
    let selectedWatch: Watch
    
    // Control the spinning animation
    @State private var isSpinning = false

    var body: some View {
        Form {
            Section(header: Text("Watch Details")) {
                VStack {
                    HStack {
                        Spacer()
                        
                        // A button that triggers spin
                        Button(action: {
                            withAnimation(Animation.linear(duration: 2.0)) {
                                // Toggle to start/stop the rotation
                                isSpinning.toggle()
                            }
                        }) {
                            // Clockwise arrow inside a circle
                            Image(systemName: "arrow.clockwise.circle.fill")
                                .font(.largeTitle)
                                .foregroundColor(.blue)
                        }
                        .padding()
                        .background(Color.white)
                        .clipShape(Circle())
                        .shadow(radius: 5)
                    }
                    
                    // Display selected watch image
                    Image(selectedWatch.imageName)
                        .resizable()
                        .cornerRadius(12.0)
                        .aspectRatio(contentMode: .fit)
                        .padding()
                        // Apply a rotation effect
                        .rotationEffect(.degrees(isSpinning ? 720 : 0))
                }
                
                // Display the name of watch
                Text(selectedWatch.name)
                    .font(.headline)
                
                // Display the description of watch
                Text(selectedWatch.description)
                    .font(.body)
                
                HStack {
                    Text("Gold").font(.headline)
                    Spacer()
                    
                    // Display a checkmark isGold is true for the watch
                    Image(systemName: selectedWatch.isGold ? "checkmark.circle" : "xmark.circle" )
                }
            }
        }
    }
}

struct WatchDetail_Previews: PreviewProvider {
    static var previews: some View {
        WatchDetail(selectedWatch: watchData[0])
    }
}
