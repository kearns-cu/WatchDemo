//
//  ContentView.swift
//  WatchShopDemo
//
//  Created by Ronan Kearns on 11/30/23.
//

import SwiftUI

struct ContentView: View {
    @StateObject var cartManager = CartManager()
    @State private var showingMessageView = false
    @State private var isCartViewActive = false
    var columns = [GridItem(.adaptive(minimum: 160), spacing: 20)]

    var body: some View {
        TabView {
            NavigationView {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        ForEach(productList, id: \.id) { product in
                            ProductCard(product: product)
                                .environmentObject(cartManager)
                        }
                    }
                    .padding()
                }
                .navigationTitle("Watch Shop")
                .toolbar {
                    ToolbarItemGroup(placement: .navigationBarTrailing) {
                        CartButton(numberOfProducts: cartManager.products.count)
                            .background(NavigationLink("", destination: CartView().environmentObject(cartManager), isActive: $isCartViewActive))
                        Button(action: {
                            showingMessageView = true
                        }) {
                            Text("Messages")
                        }
                    }
                    
                    
                }
                .sheet(isPresented: $showingMessageView) {
                    ChatMessageView()
                }
            }
            .tabItem {
                Image(systemName: "house")
                Text("Home")
            }
            
            NavigationView {
                CurrentOrdersView()
            }
            .tabItem {
                Image(systemName: "paperplane")
                Text("Current Orders")
            }
            
            NavigationView {
                CollectionView()
            }
            .tabItem {
                Image(systemName: "tray.2")
                Text("Collection")
            }
            
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

#Preview {
    ContentView()
}
