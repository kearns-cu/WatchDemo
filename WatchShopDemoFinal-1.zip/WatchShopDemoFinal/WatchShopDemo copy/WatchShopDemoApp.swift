//
//  WatchShopDemoApp.swift
//  WatchShopDemo
//
//  Created by Ronan Kearns on 11/30/23.
//

import SwiftUI

@main
struct WatchShopDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
